import Navbar from "./components/NavBar";
import Sidebar from "./components/Sidebar";
import Home from "./components/Sections/Home";
import Skills from "./components/Sections/Skills";
import Education from "./components/Sections/Education";
import Experience from "./components/Sections/Experience";
import Projects from "./components/Sections/Projects";
import CertificationsPage from "./components/Sections/CertificationsPage";
import Achievements from "./components/Sections/Achievements";
import Contact from "./components/Sections/Contact";
import { useHashRoute } from "./hooks/useHashRoute";

function App() {
  const { route, navigate } = useHashRoute();

  const renderPage = () => {
    switch (route) {
      case "skills":
        return <Skills />;
      case "education":
        return <Education />;
      case "experience":
        return <Experience />;
      case "projects":
        return <Projects showFilter />;
      case "certifications":
        return <CertificationsPage />;
      case "achievements":
        return <Achievements />;
      case "contact":
        return <Contact />;
      case "home":
      default:
        return <Home />;
    }
  };

  return (
    <div className="min-h-screen bg-surface text-ink">
      <Navbar route={route} navigate={navigate} />

      <div className="mx-auto w-full max-w-5xl px-6 pt-8 md:px-10 md:pt-10">
        <div className="lg:grid lg:grid-cols-[240px_1fr] lg:gap-12 lg:items-start lg:min-h-[calc(100vh-4rem)]">
          <Sidebar />

          <main className="min-w-0 border-t border-border lg:border-t-0 lg:border-l lg:pl-12">
            {renderPage()}
          </main>
        </div>
      </div>
    </div>
  );
}

export default App;
