import { UserRound } from "lucide-react";
import Section from "../Section";
import SectionTitle from "../SectionTitle";
import AnimatedSection from "../AnimatedSection";

export default function About() {
  return (
    <Section id="about" bordered={false}>
      <AnimatedSection>
        <SectionTitle icon={UserRound} title="About Me" />
        <div className="max-w-2xl space-y-4 text-sm leading-relaxed text-ink-secondary md:text-base">
          <p>
            I'm a 3rd year Computer Science student at Laguna State Polytechnic
            University — Los Baños Campus. I enjoy turning ideas into reality
            through code and continuously learning new technologies.
          </p>
          <p>
            My work spans full-stack web development and embedded systems — from
            building production web applications with Laravel and React, to
            designing IoT hardware integrations with microcontrollers and RFID
            systems.
          </p>
          <p>
            I'm focused on becoming a well-rounded software engineer,
            contributing to impactful projects, and building software that's
            both technically solid and genuinely useful to the people who use
            it.
          </p>
        </div>
      </AnimatedSection>
    </Section>
  );
}
