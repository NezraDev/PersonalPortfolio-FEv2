import { GraduationCap } from "lucide-react";
import SectionTitle from "../SectionTitle";
import LogoBox from "../LogoBox";
import { education } from "../../data/education";

export default function Education() {
  return (
    <div className="py-8 md:py-10">
      <SectionTitle title="Education" icon={GraduationCap} />

      <div className="space-y-6">
        {education.map((edu) => (
          <div key={edu.id} className="flex items-start gap-4">
            <LogoBox
              src={edu.logo}
              alt={`${edu.school} logo`}
              icon={GraduationCap}
            />

            <div>
              <h3 className="text-base font-semibold text-ink">{edu.school}</h3>

              {edu.campus && (
                <p className="mt-1 text-sm font-medium text-ink">
                  {edu.campus}
                </p>
              )}

              <p className="mt-1 text-sm text-ink-secondary">
                {edu.degree} {edu.major}
              </p>

              <p className="mt-1 text-sm text-ink-muted">
                {edu.startMonth} {edu.startYear} – {edu.endMonth} {edu.endYear}
              </p>

              {edu.honors?.length && (
                <p className="mt-1 text-sm italic text-ink-muted">
                  {edu.honors.join(", ")}
                </p>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
