import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "../utils/cn";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  children: ReactNode;
  variant?: "primary" | "outline" | "ghost";
  href?: string;
  target?: string;
  rel?: string;
}

export default function Button({
  children,
  variant = "primary",
  className,
  href,
  target,
  rel,
  ...props
}: ButtonProps) {
  const base =
    "inline-flex items-center justify-center gap-2 rounded-lg px-5 py-2.5 text-sm font-medium transition-all duration-200 ease-premium";

  const variants: Record<string, string> = {
    primary: "bg-ink text-surface hover:opacity-85 active:scale-[0.98]",
    outline:
      "border border-border-strong text-ink hover:border-ink hover:bg-surface-subtle active:scale-[0.98]",
    ghost: "text-ink-secondary hover:text-ink hover:bg-surface-subtle",
  };

  const classes = cn(base, variants[variant], className);

  if (href) {
    return (
      <a href={href} target={target} rel={rel} className={classes}>
        {children}
      </a>
    );
  }

  return (
    <button className={classes} {...props}>
      {children}
    </button>
  );
}
