import type { Certification } from "../types/certification";

export const certifications: Certification[] = [
  {
    id: "responsive-web-design",
    name: "Responsive Web Design",
    organization: "freeCodeCamp",
    date: "2024",
    credentialUrl:
      "https://freecodecamp.org/certification/arwilparaiso/responsive-web-design",
    logo: "/assets/logos/freecodecamp.png",
  },
  {
    id: "javascript-algorithms",
    name: "JavaScript Algorithms and Data Structures",
    organization: "freeCodeCamp",
    date: "2024",
    credentialUrl:
      "https://freecodecamp.org/certification/arwilparaiso/javascript-algorithms-and-data-structures",
    logo: "/assets/logos/freecodecamp.png",
  },
  {
    id: "sql-basic",
    name: "SQL (Basic)",
    organization: "HackerRank",
    date: "2024",
    credentialUrl:
      "https://www.hackerrank.com/certificates/arwilparaiso-sql-basic",
    logo: "/assets/logos/hackerrank.png",
  },
  {
    id: "python-basic",
    name: "Python (Basic)",
    organization: "HackerRank",
    date: "2024",
    credentialUrl:
      "https://www.hackerrank.com/certificates/arwilparaiso-python-basic",
    logo: "/assets/logos/hackerrank.png",
  },
];
